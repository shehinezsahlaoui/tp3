package com.chahinez.diplome.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.chahinez.diplome.entities.Diplome;
import com.chahinez.diplome.entities.Facultee;

@RepositoryRestResource(path = "rest")
public interface DiplomeRepository extends JpaRepository<Diplome, Long> {
	
	List<Diplome> findByNomDiplome(String nom);
	 List<Diplome> findByNomDiplomeContains(String nom); 

	/* @Query("select p from Diplome p where p.nomDiplome like %?1 and p.typeDiplome > ?2")
	 List<Diplome> findByNomType (String nom, String type);*/
	 
	 @Query("select p from Diplome p where p.nomDiplome like %:nom and p.typeDiplome > :type")
	 List<Diplome> findByNomType (@Param("nom") String nom,@Param("type") String type);

	 @Query("select p from Diplome p where p.facultee = ?1")
	
	List<Diplome> findByFacultee(Facultee cat);
	 
	 List<Diplome> findByFaculteeIdFaculte(Long id);
	 
	 List<Diplome> findByOrderByNomDiplomeAsc();
	 
	 @Query("select p from Diplome p order by p.nomDiplome ASC, p.typeDiplome DESC")
	 List<Diplome> trierDiplomesNomsType();
}